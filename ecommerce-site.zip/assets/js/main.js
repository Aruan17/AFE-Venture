
const products=[{id:1,title:"Wireless Headphones",price:2999,img:"https://i.imgur.com/6K7NlxH.jpg"},{id:2,title:"Smart Watch",price:4999,img:"https://i.imgur.com/sJ3CT4V.jpg"},{id:3,title:"Gaming Keyboard",price:2599,img:"https://i.imgur.com/1bX5QH6.jpg"},{id:4,title:"Drone Camera",price:15999,img:"https://i.imgur.com/ZKHrBq2.jpg"}];
function renderProducts(){const grid=document.getElementById("productGrid");if(!grid)return;grid.innerHTML=products.map(p=>`
    <div class="card" data-animate>
      <img src="${p.img}" alt="${p.title}">
      <div class="card-body">
        <h4 class="card-title">${p.title}</h4>
        <p class="card-price">₹${p.price}</p>
      </div>
    </div>`).join("")}
const observer=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("in-view")})},{threshold:.2});
document.querySelectorAll("[data-animate]").forEach(el=>observer.observe(el));
const contactForm=document.getElementById("contactForm");
if(contactForm){contactForm.addEventListener("submit",e=>{e.preventDefault();const name=document.getElementById("name").value.trim();const email=document.getElementById("email").value.trim();const msg=document.getElementById("message").value.trim();const formMsg=document.getElementById("formMsg");if(!name||!email||!msg){formMsg.textContent="Please fill out all fields.";}else{formMsg.textContent="Thanks, we'll get back to you soon!";contactForm.reset();}})}
const openAuth=document.getElementById("openAuth");if(openAuth){openAuth.addEventListener("click",()=>alert("Login / Sign-up coming soon!"));}
renderProducts();
